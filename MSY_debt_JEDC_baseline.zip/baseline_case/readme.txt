This folder contains the replication codes for the baseline case in
Mao, Ruoyun, Wenyi Shen, and Shu-Chun S. Yang. 
"Can passive monetary policy decrease the debt burden?." 
Journal of Economic Dynamics and Control 159 (2024): 104802.



List of files:
main.f90: main file. Compile and run this file with ifortran.
mod_param.f90: parameters
mod_eeresidual.f90: model
mod_simulation.f90: produce irfs 
other f90 files: toolbox


Output:
Running main.90 yields policy functions and IRFs for the baseline case in Mao, Shen and Yang (2024)



 